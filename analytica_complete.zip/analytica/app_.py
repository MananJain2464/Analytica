import streamlit as st
import json
import pandas as pd
from typing import Dict, List

def load_book_data(book_name: str) -> List[Dict]:
    """
    Load question data from JSON file
    """
    if book_name == "Book 1":
        with open('output.json', 'r') as file:
            return json.load(file)
    return []

def filter_questions(questions: List[Dict], question_type: str) -> List[Dict]:
    """
    Filter questions by type and sort by score in descending order.
    """
    # Filter questions by type and sort by score
    filtered_questions = [q for q in questions if q['question_type'] == question_type]
    sorted_questions = sorted(filtered_questions, key=lambda x: x['score'], reverse=True)
    return sorted_questions

def main():
    st.title("Book Question Generator")
    
    # Sidebar for selections
    st.sidebar.header("Settings")
    
    # Book selection
    book_options = ["Book 1", "Book 2", "Book 3", "Book 4", "Book 5"]
    selected_book = st.sidebar.selectbox(
        "Select a Book",
        book_options
    )
    
    # Question type selection
    question_types = ["objective", "single-line-answer", "subjective"]
    selected_question_type = st.sidebar.selectbox(
        "Select Question Type",
        question_types
    )
    
    # Load and filter questions
    if selected_book and selected_question_type:
        questions = load_book_data(selected_book)
        
        if questions:
            filtered_questions = filter_questions(questions, selected_question_type)
            
            # Display questions
            st.header(f"Questions from {selected_book}")
            
            if filtered_questions:
                for i, question in enumerate(filtered_questions, 1):
                    st.subheader(f"Question {i}")
                    
                    # Create an expander for each question
                    with st.expander("View Question Details"):
                        st.write(f"Question: {question['question']}")
                        st.write(f"Score: {question['score']}")
                        
                        # Handle tags display
                        tags = question['tag']
                        if isinstance(tags, str):
                            tags = [tag.strip() for tag in tags.split(',')]
                        st.write(f"Tags: {', '.join(tags)}")
                        
                        if question['question_type'] == 'objective':
                            st.write("Options:")
                            for idx, option in enumerate(question['options'], 1):
                                st.write(f"{idx}. {option}")
                            st.write(f"Correct Answer: Option {question['answer']}")
                        else:
                            st.write(f"Answer: {question['answer']}")
            else:
                st.warning(f"No {selected_question_type} questions found for {selected_book}")
        else:
            st.warning(f"No questions found for {selected_book}")

if __name__ == "__main__":
    main()