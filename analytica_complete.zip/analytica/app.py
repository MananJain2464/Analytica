# Sample Data Setup
import random
books_data = {
    "Gandhi: An Autobiography": {
        "tags": {
            "Nonviolence": {
                "quiz": [
                    {
                        "question": "What principle did Gandhi advocate for as a means to achieve social change?",
                        "options": ["A) Violence", "B) Nonviolence", "C) Revolution", "D) Negotiation"],
                        "answer": "B) Nonviolence"
                    }
                ],
                "one_liner": [
                    {
                        "question": "What is Gandhi's stance on violence?",
                        "answer": "Gandhi believed in nonviolence as the only effective means to achieve social change."
                    }
                ],
                "subjective": [
                    {
                        "question": "Explain the concept of nonviolence according to Gandhi and its relevance in today’s society.",
                        "answer": ("Gandhi’s concept of nonviolence is rooted in the idea that one should resist oppression "
                                   "without resorting to violence. It emphasizes the moral strength of love and compassion, "
                                   "advocating for peaceful protests and civil disobedience. In today's society, nonviolence "
                                   "is more relevant than ever as it serves as a powerful tool for social movements, "
                                   "demonstrating that change can be achieved without violence.")
                    }
                ]
            },
            "Truth": {
                "quiz": [
                    {
                        "question": "According to Gandhi, what does absolute Truth represent?",
                        "options": ["A) Lies", "B) God", "C) Reality", "D) Fiction"],
                        "answer": "B) God"
                    }
                ],
                "one_liner": [
                    {
                        "question": "How does Gandhi define Truth?",
                        "answer": "Gandhi defines Truth as the eternal principle that is synonymous with God."
                    }
                ],
                "subjective": [
                    {
                        "question": "Discuss the relationship between truth and morality in Gandhi's philosophy.",
                        "answer": ("In Gandhi’s philosophy, truth is not merely a statement of fact but encompasses moral "
                                   "integrity and alignment with one's values. He believed that living in truth leads to "
                                   "moral actions and ethical living, which are essential for personal growth and societal harmony.")
                    }
                ]
            },
            "Leadership": {
                "quiz": [
                    {
                        "question": "What quality does Gandhi believe is essential for effective leadership?",
                        "options": ["A) Authority", "B) Fear", "C) Humility", "D) Power"],
                        "answer": "C) Humility"
                    }
                ],
                "one_liner": [
                    {
                        "question": "What is Gandhi’s view on leaders?",
                        "answer": "Gandhi believed that true leaders should embody humility and serve their people selflessly."
                    }
                ],
                "subjective": [
                    {
                        "question": "Analyze Gandhi’s approach to leadership and how it differs from contemporary leadership styles.",
                        "answer": ("Gandhi’s approach to leadership was rooted in service and moral integrity, contrasting sharply "
                                   "with contemporary styles that often emphasize power and authority. He believed that leaders "
                                   "should be role models, demonstrating virtues such as humility and compassion, which can inspire trust and loyalty among followers.")
                    }
                ]
            }
        }
    },
    "The Art of War": {
        "tags": {
            "Strategy": {
                "quiz": [
                    {
                        "question": "What is the main focus of Sun Tzu's strategic philosophy?",
                        "options": ["A) Warfare", "B) Peace", "C) Negotiation", "D) Economic Development"],
                        "answer": "A) Warfare"
                    }
                ],
                "one_liner": [
                    {
                        "question": "How does Sun Tzu suggest to win a war?",
                        "answer": "Sun Tzu suggests winning without fighting is the best strategy."
                    }
                ],
                "subjective": [
                    {
                        "question": "Evaluate the relevance of Sun Tzu’s strategies in modern business.",
                        "answer": ("Sun Tzu’s strategies emphasize understanding competition and leveraging advantages, which are "
                                   "highly applicable in modern business contexts where companies must navigate market dynamics "
                                   "and competitor actions strategically. His principle of knowing oneself and one’s opponent is crucial for successful business strategies.")
                    }
                ]
            },
            "Leadership": {
                "quiz": [
                    {
                        "question": "According to Sun Tzu, what is a key trait of a successful leader?",
                        "options": ["A) Aggression", "B) Wisdom", "C) Fearlessness", "D) Indifference"],
                        "answer": "B) Wisdom"
                    }
                ],
                "one_liner": [
                    {
                        "question": "What role does leadership play in Sun Tzu's teachings?",
                        "answer": "Leadership is crucial in implementing strategy and maintaining morale."
                    }
                ],
                "subjective": [
                    {
                        "question": "Discuss the qualities of a leader as presented in 'The Art of War' and their application in today’s leadership challenges.",
                        "answer": ("'The Art of War' presents leaders as wise, adaptable, and strategic thinkers, qualities that remain essential "
                                   "in today’s leadership. Modern leaders face complex challenges and must demonstrate emotional intelligence, "
                                   "strategic foresight, and the ability to inspire and guide their teams through uncertainty.")
                    }
                ]
            },
            "Conflict": {
                "quiz": [
                    {
                        "question": "What does Sun Tzu state about conflict?",
                        "options": ["A) It should be avoided", "B) It is inevitable", "C) It is a sign of weakness", "D) It is unresolvable"],
                        "answer": "B) It is inevitable"
                    }
                ],
                "one_liner": [
                    {
                        "question": "How should conflicts be managed according to Sun Tzu?",
                        "answer": "Conflicts should be managed through strategic planning and understanding of the situation."
                    }
                ],
                "subjective": [
                    {
                        "question": "Analyze how Sun Tzu’s principles can be applied to resolve conflicts in personal and professional settings.",
                        "answer": ("Sun Tzu’s principles highlight the importance of understanding the underlying issues in a conflict and strategically "
                                   "navigating them. In personal and professional settings, this can involve effective communication, negotiation, "
                                   "and seeking win-win solutions, ensuring that conflicts are resolved constructively.")
                    }
                ]
            }
        }
    },
    "To Kill a Mockingbird": {
        "tags": {
            "Justice": {
                "quiz": [
                    {
                        "question": "What is the central theme regarding justice in 'To Kill a Mockingbird'?",
                        "options": ["A) Injustice", "B) Fairness", "C) Revenge", "D) Indifference"],
                        "answer": "B) Fairness"
                    }
                ],
                "one_liner": [
                    {
                        "question": "How is justice portrayed in the novel?",
                        "answer": "Justice is portrayed as a complex and often flawed ideal in the face of societal prejudice."
                    }
                ],
                "subjective": [
                    {
                        "question": "Discuss the portrayal of justice in the novel and its implications for contemporary society.",
                        "answer": ("'To Kill a Mockingbird' portrays justice as an ideal often hindered by societal biases, reflecting ongoing issues "
                                   "in contemporary society regarding race, class, and fairness within the legal system. The novel encourages readers "
                                   "to reflect on their own beliefs about justice and the systems that uphold or undermine it.")
                    }
                ]
            },
            "Racism": {
                "quiz": [
                    {
                        "question": "What role does racism play in the narrative of 'To Kill a Mockingbird'?",
                        "options": ["A) It is absent", "B) It is a central theme", "C) It is trivial", "D) It is resolved"],
                        "answer": "B) It is a central theme"
                    }
                ],
                "one_liner": [
                    {
                        "question": "How does the novel address racism?",
                        "answer": "The novel addresses racism through the injustices faced by the black community, particularly in the trial of Tom Robinson."
                    }
                ],
                "subjective": [
                    {
                        "question": "Evaluate the impact of racism on the characters and plot development in the novel.",
                        "answer": ("Racism significantly impacts the characters' lives and drives the plot, shaping their experiences and moral decisions. "
                                   "It highlights the destructive nature of prejudice and challenges the reader to confront the realities of systemic racism both in the past and present.")
                    }
                ]
            },
            "Childhood": {
                "quiz": [
                    {
                        "question": "How does the narrative of childhood influence the story?",
                        "options": ["A) It is irrelevant", "B) It provides a perspective on adult issues", "C) It is the only focus", "D) It distracts from the plot"],
                        "answer": "B) It provides a perspective on adult issues"
                    }
                ],
                "one_liner": [
                    {
                        "question": "How is childhood depicted in the novel?",
                        "answer": "Childhood is depicted as a time of innocence that is challenged by the harsh realities of the adult world."
                    }
                ],
                "subjective": [
                    {
                        "question": "Analyze how the experiences of childhood shape the characters’ views on morality and justice.",
                        "answer": ("The experiences of childhood in 'To Kill a Mockingbird' shape the characters’ understanding of morality and justice as they grapple "
                                   "with complex social issues. Through the eyes of Scout and Jem, readers see the gradual loss of innocence and the awakening to "
                                   "the moral complexities of their community, which shapes their values and beliefs as they grow.")
                    }
                ]
            }
        }
    }
}

# Example Usage in Streamlit
import streamlit as st

st.title("AI-Based Question Extraction")

# Step 1: Book Selection
selected_book = st.selectbox("Select a Book", options=list(books_data.keys()))

# Step 2: Question Type Selection
question_type = st.selectbox("Select Question Type", options=["Quiz", "one_liner", "Subjective"])

# Step 3: Tag Selection
tags_options = list(books_data[selected_book]["tags"].keys())
selected_tag = st.selectbox("Select Tag", options=tags_options)

# Step 4: Display Question Generation Options
if question_type == "Quiz":
    num_questions = st.number_input("Select Number of Questions", min_value=1, max_value=10, value=4)
    start_quiz = st.button("Start Quiz")

if st.button("Generate Questions"):
    questions = books_data[selected_book]["tags"][selected_tag][question_type.lower()]
    if question_type == "Quiz":
        selected_questions = random.sample(questions, min(num_questions, len(questions)))
        st.subheader("Quiz Questions")
        for idx, q in enumerate(selected_questions):
            st.write(f"**Q{idx + 1}: {q['question']}**")
            for option in q['options']:
                st.write(f"- {option}")
            # Optionally, you could add a timer or scoring system here
    elif question_type == "one_liner":
        st.subheader("One-liner Questions")
        for q in questions:
            st.write(f"**{q['question']}**")
            st.write(f"*Answer: {q['answer']}*")
    elif question_type == "Subjective":
        st.subheader("Subjective Questions")
        for q in questions:
            st.write(f"**{q['question']}**")
            st.write(f"*Answer: {q['answer']}*")

