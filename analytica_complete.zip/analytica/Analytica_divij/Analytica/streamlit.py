import streamlit as st
import random

# Sample book data (kept the same as your original)
book_data = {
    'Book 1': {
        'tags': ['tag1', 'tag2'],
        'questions': {
            'quiz': [
                {
                    'question': 'What is the capital of France?',
                    'options': ['Berlin', 'Madrid', 'Paris', 'Rome'],
                    'answer': 'Paris'
                },
                {
                    'question': 'What is 2 + 2?',
                    'options': ['3', '4', '5', '6'],
                    'answer': '4'
                },
            ],
            'one-liner': [
                {
                    'question': 'What is the boiling point of water?',
                    'answer': '100°C'
                },
                {
                    'question': 'What is the capital of Japan?',
                    'answer': 'Tokyo'
                },
            ],
            'subjective': [
                {
                    'question': 'Describe the process of photosynthesis.',
                    'answer': 'Photosynthesis is the process by which green plants use sunlight...'
                },
                {
                    'question': 'Explain the significance of the Magna Carta.',
                    'answer': 'The Magna Carta established the principle that everyone is subject to the law...'
                },
            ]
        }
    },
    'Book 2': {
        'tags': ['tag3', 'tag4'],
        'questions': {
            'quiz': [
                {
                    'question': 'What is the largest planet in our solar system?',
                    'options': ['Earth', 'Jupiter', 'Mars', 'Saturn'],
                    'answer': 'Jupiter'
                },
                {
                    'question': 'What is the chemical symbol for water?',
                    'options': ['O2', 'H2O', 'CO2', 'NaCl'],
                    'answer': 'H2O'
                },
            ],
        }
    },
}

# Initialize session state
if 'current_questions' not in st.session_state:
    st.session_state.current_questions = []
if 'user_answers' not in st.session_state:
    st.session_state.user_answers = {}
if 'quiz_generated' not in st.session_state:
    st.session_state.quiz_generated = False
if 'score' not in st.session_state:
    st.session_state.score = 0
if 'show_results' not in st.session_state:
    st.session_state.show_results = False

# Streamlit App
st.title('AI Based Question Extraction')

# Select book
selected_book = st.selectbox('Select a Book', list(book_data.keys()))

# Select question type
question_type = st.selectbox('Select Question Type', ['quiz', 'one-liner', 'subjective'])

# Select tags
selected_tag = st.selectbox('Select Tag', book_data[selected_book]['tags'])

# Set the number of questions for the quiz
num_questions = st.number_input('Number of Questions', min_value=1, max_value=10, value=1)

def generate_quiz():
    questions = book_data[selected_book]['questions'][question_type]
    st.session_state.current_questions = random.sample(questions, min(num_questions, len(questions)))
    st.session_state.quiz_generated = True
    st.session_state.user_answers = {}
    st.session_state.show_results = False

def submit_quiz():
    st.session_state.show_results = True
    st.session_state.score = sum(
        1 for i, q in enumerate(st.session_state.current_questions)
        if st.session_state.user_answers.get(i) == q['answer']
    )

# Generate questions button
if st.button('Generate Questions'):
    generate_quiz()

# Display questions based on type
if question_type == 'quiz' and st.session_state.quiz_generated:
    for i, q in enumerate(st.session_state.current_questions):
        st.subheader(f"Question {i + 1}: {q['question']}")
        
        # Use radio buttons instead of checkboxes
        answer = st.radio(
            f"Select your answer for question {i + 1}:",
            options=q['options'],
            key=f"q_{i}",
            index=None
        )
        
        # Store the answer in session state
        if answer is not None:
            st.session_state.user_answers[i] = answer

    # Show submit button only if all questions are answered
    if len(st.session_state.user_answers) == len(st.session_state.current_questions):
        if st.button('Submit Quiz'):
            submit_quiz()

    # Display results if quiz is submitted
    if st.session_state.show_results:
        st.markdown("---")
        st.subheader("Quiz Results")
        for i, q in enumerate(st.session_state.current_questions):
            user_answer = st.session_state.user_answers.get(i)
            correct = user_answer == q['answer']
            
            if correct:
                st.success(f"Question {i + 1}: Correct! Your answer: {user_answer}")
            else:
                st.error(f"Question {i + 1}: Incorrect. Your answer: {user_answer}, Correct answer: {q['answer']}")
        
        st.markdown(f"### Final Score: {st.session_state.score}/{len(st.session_state.current_questions)}")
        
        if st.button('Try Again'):
            generate_quiz()

elif question_type == 'one-liner':
    questions = book_data[selected_book]['questions'].get('one-liner', [])
    for q in questions:
        st.subheader(q['question'])
        st.write(q['answer'])

elif question_type == 'subjective':
    questions = book_data[selected_book]['questions'].get('subjective', [])
    for q in questions:
        st.subheader(q['question'])
        st.write(q['answer'])