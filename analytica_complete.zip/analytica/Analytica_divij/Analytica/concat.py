import pandas as pd
import os

def concatenate_csv_files():
    # List of input CSV files with proper path formatting
    csv_files = [
        r'C:\Users\divij\OneDrive\Desktop\Analytica\extracted_questions_tig.csv',
        r'C:\Users\divij\OneDrive\Desktop\Analytica\extracted_questions_tig2.csv',
        r'C:\Users\divij\OneDrive\Desktop\Analytica\extracted_questions_tig3.csv'
    ]
    
    # List to store individual dataframes
    dfs = []
    
    # Read each CSV file
    for file in csv_files:
        if os.path.exists(file):
            try:
                df = pd.read_csv(file)
                dfs.append(df)
            except Exception as e:
                print(f"Error reading {file}: {str(e)}")
        else:
            print(f"File not found: {file}")
    
    if not dfs:
        print("No CSV files were successfully read.")
        return
    
    # Concatenate all dataframes
    combined_df = pd.concat(dfs, ignore_index=True)
    
    # Save the combined dataframe to a new CSV file
    output_file = r'C:\Users\divij\OneDrive\Desktop\Analytica\combined_questions.csv'
    combined_df.to_csv(output_file, index=False)  # Fixed method name from write_csv to to_csv
    print(f"Successfully created {output_file}")
    print(f"Total rows in combined file: {len(combined_df)}")

if __name__ == "__main__":
    concatenate_csv_files()