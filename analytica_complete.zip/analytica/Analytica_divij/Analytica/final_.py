import streamlit as st
import pandas as pd

# File path for the CSV data source
csv_file_path = "C:\\Users\\divij\\OneDrive\\Desktop\\Analytica\\final_data_un (1).csv"

# Load the CSV data
@st.cache_data
def load_data():
    df = pd.read_csv(csv_file_path)
    return df

data = load_data()

# Book tags dictionary
top_tags_per_book = {
    "book1": ['morality', "'Gandhi'", 'Gandhi', 'Truth', "'Education'", 'Simplicity', 'peace', 'spirituality', 'Morality', "'responsibility'", "['Autobiography'", 'society', "'Truth'", 'Humility', 'education', "['leadership'", "['Gandhi'", 'Profession', 'Law', 'nationality'],
    "book2": ['Spirituality', 'God', "'God'", 'Faith', 'Hinduism', "'Spirituality']", "'spirituality'", 'Philosophy', 'Truth', 'Brahmacharya', 'spirituality', 'Morality', "['God'", "'Faith'", 'self-control', 'Religion', "'Religion'", "['religion'", 'Non-violence', "['salvation'"],
    "book3": ['पापनाशी', 'थायस', 'प्रेम', 'जीवन', "['पापनाशी'", 'ईश्वर', 'Papanashi', 'ननससयास', 'अलंकार', 'मृत्यु', 'तपस्वी', 'पाप', 'वासना', 'शहर', 'धमार्श्सम', "['योगी'", 'अध्यात्म', 'प्रेमचंद', "'थायस'", 'सुख'],
    "book4": ['होरी', 'परिवार', 'गोबर', 'प्रेम', 'मालती', 'संबंध', 'मेहता', 'खन्ना', 'धनिया', 'समाज', 'रायसाहब', 'विवाह', 'दातादीन', 'हीरा', 'धन', 'गोदान', "['गोबर'", "'होरी'", 'गाय', "'मेहता'"],
    "book5": ['जीवन', 'सुख', 'धन', 'राजा', 'मन', 'यश', 'धम\ue303', 'महाभारत', 'राजकारण', 'दान', 'शोक', 'काळ', 'तप', 'ज्ञान', 'सुभाषित', 'गुण', 'धम', 'राजे', 'निर्णय', 'स्वाधीन']
}

# Streamlit UI
st.title("Question Generator")

# Step 1: Select a Book
book = st.selectbox("Select a book", ["book1", "book2", "book3", "book4", "book5"])

# Step 2: Show the tags for the selected book
st.write(f"Tags for {book}:")
tags = top_tags_per_book[book]
selected_tags = st.multiselect("Select tags", tags)

# Step 3: Select language for the questions
language = st.selectbox("Select the language", ["English", "Hindi", "Marathi", "Other"])

# Step 4: Choose question type (objective or subjective)
question_type = st.radio("Select question type", ["Objective", "Subjective"])

# Filter questions based on the selected book, question type, and tags
filtered_data = data[
    (data['book'] == book) & 
    (data['question_type'].str.lower() == question_type.lower()) &
    (data['tag'].isin(selected_tags) if selected_tags else True)
]

# Sort filtered questions by score in descending order
filtered_data = filtered_data.sort_values(by='score', ascending=False)

# Display filtered questions
if not filtered_data.empty:
    st.write(f"Questions from {book} ({question_type}) with selected tags:")
    st.dataframe(filtered_data[['question', 'tag', 'score', 'options', 'answer']])
else:
    st.write(f"No questions found for {book} with the selected criteria.")

