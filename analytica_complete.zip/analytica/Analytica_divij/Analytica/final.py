import streamlit as st
import pandas as pd
import json
from langdetect import detect, LangDetectException
from transformers import MarianMTModel, MarianTokenizer
import ast

# Configure page
st.set_page_config(page_title="Multilingual Question Generator", layout="wide")

# Initialize session state for model caching
if 'translation_models' not in st.session_state:
    st.session_state.translation_models = {}

# Load the CSV data
@st.cache_data
def load_data():
    try:
        csv_file_path = r"C:\Users\divij\OneDrive\Desktop\Analytica\final_data_un (1).csv"
        df = pd.read_csv(csv_file_path)
        return df
    except Exception as e:
        st.error(f"Error loading CSV file: {str(e)}")
        return pd.DataFrame()

# Book tags dictionary
top_tags_per_book = {
    "book1": ['morality', "'Gandhi'", 'Gandhi', 'Truth', "'Education'", 'Simplicity', 'peace', 'spirituality', 'Morality', "'responsibility'", "['Autobiography'", 'society', "'Truth'", 'Humility', 'education', "['leadership'", "['Gandhi'", 'Profession', 'Law', 'nationality'],
    "book2": ['Spirituality', 'God', "'God'", 'Faith', 'Hinduism', "'Spirituality']", "'spirituality'", 'Philosophy', 'Truth', 'Brahmacharya', 'spirituality', 'Morality', "['God'", "'Faith'", 'self-control', 'Religion', "'Religion'", "['religion'", 'Non-violence', "['salvation'"],
    "book3": ['पापनाशी', 'थायस', 'प्रेम', 'जीवन', "['पापनाशी'", 'ईश्वर', 'Papanashi', 'ननससयास', 'अलंकार', 'मृत्यु', 'तपस्वी', 'पाप', 'वासना', 'शहर', 'धमार्श्सम', "['योगी'", 'अध्यात्म', 'प्रेमचंद', "'थायस'", 'सुख'],
    "book4": ['होरी', 'परिवार', 'गोबर', 'प्रेम', 'मालती', 'संबंध', 'मेहता', 'खन्ना', 'धनिया', 'समाज', 'रायसाहब', 'विवाह', 'दातादीन', 'हीरा', 'धन', 'गोदान', "['गोबर'", "'होरी'", 'गाय', "'मेहता'"],
    "book5": ['जीवन', 'सुख', 'धन', 'राजा', 'मन', 'यश', 'धम', 'महाभारत', 'राजकारण', 'दान', 'शोक', 'काळ', 'तप', 'ज्ञान', 'सुभाषित', 'गुण', 'धम', 'राजे', 'निर्णय', 'स्वाधीन']
}

# Language configuration
# Language configuration
LANGUAGE_CODES = {
    "English": "en",
    "Hindi": "hi",
    "Marathi": "mr",
    "Sanskrit": "sa"
}

LANGUAGE_PAIRS = {
    ("en", "hi"): "Helsinki-NLP/opus-mt-en-hi",
    ("hi", "en"): "Helsinki-NLP/opus-mt-hi-en",
    ("en", "mr"): "Helsinki-NLP/opus-mt-en-mr",
    ("mr", "en"): "Helsinki-NLP/opus-mt-mr-en",
    ("en", "sa"): "Helsinki-NLP/opus-mt-en-sa",
    ("sa", "en"): "Helsinki-NLP/opus-mt-sa-en",
    ("hi", "mr"): "Helsinki-NLP/opus-mt-hi-mr",
    ("mr", "hi"): "Helsinki-NLP/opus-mt-mr-hi",
    ("hi", "sa"): "Helsinki-NLP/opus-mt-hi-sa",
    ("sa", "hi"): "Helsinki-NLP/opus-mt-sa-hi",
    ("mr", "sa"): "Helsinki-NLP/opus-mt-mr-sa",
    ("sa", "mr"): "Helsinki-NLP/opus-mt-sa-mr"
}




@st.cache_resource
def load_translation_model(src_lang, tgt_lang):
    """Load and cache translation model"""
    try:
        model_name = LANGUAGE_PAIRS.get((src_lang, tgt_lang))
        if not model_name:
            st.warning(f"Translation not available for {src_lang} to {tgt_lang}")
            return None, None
            
        tokenizer = MarianTokenizer.from_pretrained(model_name)
        model = MarianMTModel.from_pretrained(model_name)
        return model, tokenizer
    except Exception as e:
        st.error(f"Error loading translation model: {str(e)}")
        return None, None

def translate_text(text, src_lang, tgt_lang):
    """Translate text between languages"""
    if not text or src_lang == tgt_lang:
        return text
        
    try:
        model, tokenizer = load_translation_model(src_lang, tgt_lang)
        if not model or not tokenizer:
            return text
            
        inputs = tokenizer.encode(text, return_tensors="pt", max_length=512, truncation=True)
        outputs = model.generate(inputs, max_length=512)
        translated = tokenizer.decode(outputs[0], skip_special_tokens=True)
        return translated
    except Exception as e:
        st.warning(f"Translation failed: {str(e)}")
        return text


def detect_language(text):
    """Detect language of text"""
    try:
        return detect(text)
    except LangDetectException:
        return "en"  # Default to English if detection fails

def process_tags(tags_str):
    """Process tags string into list"""
    try:
        if isinstance(tags_str, str):
            # Remove quotes and brackets
            tags_str = tags_str.replace("'", "").replace("[", "").replace("]", "")
            return [tag.strip() for tag in tags_str.split(",")]
        return []
    except Exception:
        return []

def main():
    st.title("Multilingual Question Generator")
    
    # Load data
    data = load_data()
    if data.empty:
        st.error("Failed to load question data")
        return

    # Sidebar controls
    with st.sidebar:
        st.header("Settings")
        book = st.selectbox("Select Book", list(top_tags_per_book.keys()))
        
        # Show and select tags
        st.subheader("Available Tags")
        tags = top_tags_per_book[book]
        selected_tags = st.multiselect("Select Tags", tags)
        
        # Language selection
        target_language = st.selectbox("Select Output Language", list(LANGUAGE_CODES.keys()))
        target_lang_code = LANGUAGE_CODES[target_language]
        
        # Question type selection
        question_type = st.radio("Select Question Type", ["Objective", "Subjective"])

    # Filter questions
    try:
        filtered_data = data[
            (data['book'] == book) & 
            (data['question_type'].str.lower() == question_type.lower())
        ]
        
        if selected_tags:
            filtered_data = filtered_data[
                filtered_data['tag'].apply(lambda x: any(tag in process_tags(x) for tag in selected_tags))
            ]
        
        filtered_data = filtered_data.sort_values(by='score', ascending=False)
    except Exception as e:
        st.error(f"Error filtering questions: {str(e)}")
        return

    # Display questions
    if filtered_data.empty:
        st.warning("No questions found matching the selected criteria")
        return

    st.subheader(f"Questions from {book}")
    
    for idx, row in filtered_data.iterrows():
        with st.expander(f"Question {idx + 1}"):
            try:
                # Get question data
                question = row['question']
                src_lang = detect_language(question)
                
                # Translate question
                translated_question = translate_text(question, src_lang, target_lang_code)
                st.markdown(f"**Question:** {translated_question}")
                
                if question_type.lower() == "objective":
                    # Handle objective questions
                    try:
                        options = ast.literal_eval(row['options']) if isinstance(row['options'], str) else row['options']
                        correct_answer = row['answer']
                        
                        # Translate options and answer
                        translated_options = [translate_text(opt, src_lang, target_lang_code) for opt in options]
                        translated_answer = translate_text(correct_answer, src_lang, target_lang_code)
                        
                        st.markdown("**Options:**")
                        for opt in translated_options:
                            st.markdown(f"- {opt}")
                        st.markdown(f"**Correct Answer:** {translated_answer}")
                    except Exception as e:
                        st.error(f"Error processing options: {str(e)}")
                else:
                    # Handle subjective questions
                    answer = row['answer']
                    translated_answer = translate_text(answer, src_lang, target_lang_code)
                    st.markdown(f"**Answer:** {translated_answer}")
                
                # Display metadata
                st.markdown(f"**Score:** {row['score']}")
                st.markdown(f"**Tags:** {row['tag']}")
                
            except Exception as e:
                st.error(f"Error processing question {idx + 1}: {str(e)}")

if __name__ == "__main__":
    main()